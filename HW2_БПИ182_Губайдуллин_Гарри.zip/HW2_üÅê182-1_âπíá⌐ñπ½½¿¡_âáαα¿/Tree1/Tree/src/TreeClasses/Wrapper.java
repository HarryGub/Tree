package TreeClasses;

public interface Wrapper<T extends Number> {
    public T getValue();
}
